@extends('layouts.app')

@section('content')
<div class="content">
    <div class="text-center">
        <h1>Liste des albums</h1>
    </div>

    <div class="text-center">
        <a href="https://laravel.com/docs">Liste des albums</a>
        <a href="https://laracasts.com">Liste des photos</a>
    </div>
    <br>
    <br>
    <br>
    <div id="liste-des-albums" class="text-center"></div>
    <script>listeDesalbums();</script>
</div>
@endsection