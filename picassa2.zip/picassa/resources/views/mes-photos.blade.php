@extends('layouts.app')

@section('content')
<div class="content text-center">
    <br>
    <br>
    <br>
    <h1>Mes photos</h1>
    <br>
    <h3>Utilisateur : • {{ Auth::user()->name }} •</h3>
    <br>
    <br>
    <br>
    <div id="liste-des-photos" class="text-center"></div>
    <script>afficherMesphotos();</script>
</div>
@endsection