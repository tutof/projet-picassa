<?php $__env->startSection('content'); ?>
<div class="content text-center">
        <br>
        <br>
        <br>
        <h1>Créer un album</h1>
        <br>
        <h3>• <?php echo e(Auth::user()->name); ?> •</h3>
        <br>
        <br>
        <br>
        <form id="formAjouterAlbum" class="mx-auto text-center form-horizontal" style="width: 500px;" action="<?php echo e(route('ajouter-album')); ?>" method="POST" enctype="multipart/form-data">
            <input placeholder="Saisir le nom de l'album" required class="w-100" style="width: 300px;" type="text" id="album-nom" name="nom" class="nom" class="form-control">
            <?php echo csrf_field(); ?>
            <br>
            <br>
            <br>
            <button class="btn btn-success" type="submit">Ajouter l'album</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\1833\Documents\LP-Creaweb\picassa\picassa\resources\views///creer-un-album.blade.php ENDPATH**/ ?>