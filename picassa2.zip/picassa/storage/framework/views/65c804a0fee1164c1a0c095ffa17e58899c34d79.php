<?php $__env->startSection('content'); ?>
<div class="content text-center">
    <br>
    <br>
    <br>
    <h1>Mes photos</h1>
    <br>
    <h3>Utilisateur : • <?php echo e(Auth::user()->name); ?> •</h3>
    <br>
    <br>
    <br>
    <div id="liste-des-photos" class="text-center"></div>
    <script>afficherMesphotos();</script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\1833\Documents\LP-Creaweb\picassa\picassa\resources\views///mes-photos.blade.php ENDPATH**/ ?>