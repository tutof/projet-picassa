<?php $__env->startSection('content'); ?>
<div class="content text-center">
    <br>
    <br>
    <br>
    <h1>• Utilisateur : <?php echo e(Auth::user()->name); ?> •</h1>
    <br>
    <h2>• email : <?php echo e(Auth::user()->email); ?> •</h2>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\1833\Documents\LP-Creaweb\picassa\picassa\resources\views///mon-compte.blade.php ENDPATH**/ ?>