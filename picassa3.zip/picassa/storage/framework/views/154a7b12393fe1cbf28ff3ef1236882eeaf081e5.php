<?php $__env->startSection('content'); ?>
    <div class="content text-center">
        <br>
        <br>
        <br>
        <h1>Ajouter une photo</h1>
        <br>
        <h3>• <?php echo e(Auth::user()->name); ?> •</h3>
        <br>
        <br>
        <br>
        <form id="formAjouterPhoto" class="mx-auto text-center form-horizontal" style="width: 500px;" action="<?php echo e(route('ajouter-photo')); ?>" method="POST" enctype="multipart/form-data">
            <input placeholder="Saisir le nom de la photo" required class="w-100" style="width: 300px;" type="text" id="photo-nom" name="nom" class="nom" class="form-control">
            <br>
            <br>
            <br>
            <select required id='listeAlbum' name="album" style='width: 300px;'>
            </select>
            <br>
            <br>
            <br>
            <input required class="w-100" style="width: 500px;" type="file" name="image" id="photo-image" class="form-control">
            <?php echo csrf_field(); ?>
            <br>
            <br>
            <br>
            <button class="btn btn-success" type="submit">Ajouter l'image</button>
        </form>
    </div>
    <script>listeAlbumSelect();</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\1833\Documents\LP-Creaweb\picassa\picassa\resources\views///ajouter-une-photo.blade.php ENDPATH**/ ?>