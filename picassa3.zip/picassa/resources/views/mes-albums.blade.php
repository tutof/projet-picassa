@extends('layouts.app')

@section('content')
<div class="content text-center">
    <br>
    <br>
    <br>
    <h1>Mes albums</h1>
    <br>
    <h3>Utilisateur : • {{ Auth::user()->name }} •</h3>
    <br>
    <br>
    <br>
    <div id="liste-des-albums" class="text-center align-middle"></div>
    <script>afficherMesalbums();</script>
</div>
@endsection