@extends('layouts.app')

@section('content')
<div class="content text-center">
        <br>
        <br>
        <br>
        <h1>Créer un album</h1>
        <br>
        <h3>• {{ Auth::user()->name }} •</h3>
        <br>
        <br>
        <br>
        <form id="formAjouterAlbum" class="mx-auto text-center form-horizontal" style="width: 500px;" action="{{ route('ajouter-album') }}" method="POST" enctype="multipart/form-data">
            <input placeholder="Saisir le nom de l'album" required class="w-100" style="width: 300px;" type="text" id="album-nom" name="nom" class="nom" class="form-control">
            @csrf
            <br>
            <br>
            <br>
            <button class="btn btn-success" type="submit">Ajouter l'album</button>
        </form>
    </div>
@endsection