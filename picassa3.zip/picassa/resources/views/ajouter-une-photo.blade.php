@extends('layouts.app')

@section('content')
    <div class="content text-center">
        <br>
        <br>
        <br>
        <h1>Ajouter une photo</h1>
        <br>
        <h3>• {{ Auth::user()->name }} •</h3>
        <br>
        <br>
        <br>
        <form id="formAjouterPhoto" class="mx-auto text-center form-horizontal" style="width: 500px;" action="{{ route('ajouter-photo') }}" method="POST" enctype="multipart/form-data">
            <input placeholder="Saisir le nom de la photo" required class="w-100" style="width: 300px;" type="text" id="photo-nom" name="nom" class="nom" class="form-control">
            <br>
            <br>
            <br>
            <select required id='listeAlbum' name="album" style='width: 300px;'>
            </select>
            <br>
            <br>
            <br>
            <input required class="w-100" style="width: 500px;" type="file" name="image" id="photo-image" class="form-control">
            @csrf
            <br>
            <br>
            <br>
            <button class="btn btn-success" type="submit">Ajouter l'image</button>
        </form>
    </div>
    <script>listeAlbumSelect();</script>
@stop