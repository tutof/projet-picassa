@extends('layouts.app')

@section('content')
<div class="content text-center">
    <br>
    <br>
    <br>
    <h1>• Utilisateur : {{ Auth::user()->name }} •</h1>
    <br>
    <h2>• email : {{ Auth::user()->email }} •</h2>
</div>
@endsection