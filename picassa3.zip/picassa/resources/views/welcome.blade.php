@extends('layouts.app')

@section('content')
<div class="container-fluid">

    <h1 class="titre">Picassa</h1>
    <h2 id="h2bienvenue" class="text-center">Partagez dès maintenant vos meilleurs photos en ligne !</h2>

    <div class="text-center">
        <img src="img/homepage.jpg" class="imghome">
    </div>

    <div class="box-btns">
        <a href="/liste-des-photos/"><div class="btns">Voir les photos</div></a>
        <a href="/liste-des-albums/"><div class="btns">Voir les albums</div></a>
    </div>
</div>
@endsection
