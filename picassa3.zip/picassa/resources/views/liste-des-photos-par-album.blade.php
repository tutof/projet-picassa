@extends('layouts.app')

@section('content')
<div class="content">
    <div class="text-center">
       <h1>Liste des photos</h1>
    </div>

    <div class="text-center">
        <a href="https://laravel.com/docs">Liste des albums</a>
        <a href="https://laracasts.com">Liste des photos</a>
    </div>
    <br>
    <br>
    <br>
    <div id="liste-des-photos" class="text-center"></div>
    <script>listeDesPhotosParAlbum();</script>
</div>
@endsection