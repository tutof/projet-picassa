<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class Users extends Controller
{
    function ajouterPhotos(Request $req) {

        $id = DB::table('users')->where('email', Auth::user()->email)->value('id');
        $idphoto = DB::table('photo')->insertGetId(['nom' => $req->post('nom'), 'fichier' => $req->file('image')->store('public'), 'post_date' => date('Y-m-d H:i:s'), 'style' => 'no', 'utilisateur_id' => $id]);
        DB::table('contient')->insertGetId(['album_id' => $req->post('album'), 'photo_id' => $idphoto]);
        echo $req->post('album');

    }

    function ajouterAlbum(Request $req) {

        $id = DB::table('users')->where('email', Auth::user()->email)->value('id');
        DB::table('album')->insertGetId(['nom' => $req->post('nom'), 'realisateur_id' => $id]);

    }

    function mesPhotos(Request $req) {

        $id = DB::table('users')->where('email', Auth::user()->email)->value('id');

        $listeDesPhotos = DB::table('photo')->where('utilisateur_id', $id)->get();
        $lesphotos = "";

        if ($listeDesPhotos->count() == 0) {
            $lesphotos = "<p>Aucune photo disponible</p>";
        } else {
            foreach ($listeDesPhotos as $photo)
            {
                $immgLoc = $photo->fichier;
                $imgName = $photo->nom;
                $lesphotos .= "<div><img title='" . $imgName . "' alt='" . $imgName . "' src='/storage" . substr($immgLoc, 6) . "' class='img-thumbnail'>"; 
                $lesphotos .= "<br><p><strong>Nom : </strong>" . $imgName . "</p></div>";
            }
        }
        // $lesphotos = "<img alt='photo1' src='/storage/ok.png'>";
        echo $lesphotos;
    }

    function mesAlbums(Request $req) {

        $id = DB::table('users')->where('email', Auth::user()->email)->value('id');

        $listeDesAlbums = DB::table('album')->where('realisateur_id', $id)->get();
        $lesalbums = "";

        if ($listeDesAlbums->count() == 0) {
            $lesalbums = "<p>Aucun Album disponible</p>";
        } else {
            foreach ($listeDesAlbums as $album)
            {
                $albumName = $album->nom;
                $lesalbums .= "<div class='mx-auto card' style='width: 150px;margin: 15px;'><img class='card-img-top' title='" . $albumName . "' alt='" . $albumName . "' src='https://cdn.pixabay.com/photo/2014/02/02/17/41/photo-256889_960_720.jpg' class='img-thumbnail'>"; 
                $lesalbums .= "<br><p><strong>Nom de l'album : </strong>" . $albumName . "</p><br><a href='#' target='_blank' class='btn btn-info'>Voir les photos</a></div>";
            }
        }
        echo $lesalbums;
    }
}
