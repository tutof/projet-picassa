<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class Picassa extends Controller
{
    function listeDesPhotos(Request $req) {

        $listeDesPhotos = DB::table('photo')->get();
        $lesphotos = "";

        if ($listeDesPhotos->count() == 0) {
            $lesphotos = "<p>Aucune photo disponible</p>";
        } else {
            foreach ($listeDesPhotos as $photo)
            {
                $immgLoc = $photo->fichier;
                $imgName = $photo->nom;
                $lesphotos .= "<div><img style='width:150px;' title='" . $imgName . "' alt='" . $imgName . "' src='/storage" . substr($immgLoc, 6) . "' class='img-thumbnail'>"; 
                $lesphotos .= "<br><p><strong>Nom : </strong>" . $imgName . "</p></div>";
            }
        }

        echo $lesphotos;
       
    }
    
    function listeDesAlbums(Request $req) {

        $listeDesAlbums = DB::table('album')->get();
        $lesalbums = "";

        if ($listeDesAlbums->count() == 0) {
            $lesalbums = "<p>Aucun album disponible</p>";
        } else {
            foreach ($listeDesAlbums as $album)
            {
                $albumName = $album->nom;
                $albumId = $album->id;
                $lesalbums .= "<div class='mx-auto card' style='width: 150px;margin: 15px;'><img class='card-img-top' title='" . $albumName . "' alt='" . $albumName . "' src='https://cdn.pixabay.com/photo/2014/02/02/17/41/photo-256889_960_720.jpg' class='img-thumbnail'>"; 
                $lesalbums .= "<br><p><strong>Nom de l'album : </strong>" . $albumName . "</p><br><a href='/liste-des-photos-par-album/" . $albumId . "/' target='_self' class='btn btn-info'>Voir les photos</a></div>";
            }
        }

        echo $lesalbums;
       
    }

    function listeDesPhotosParAlbum(Request $req) {

         $listeDesPhotos = DB::table('contient')
            ->join('photo', function ($join) {
                $join->on('contient.photo_id', '=', 'photo.id');
            })
            ->where('contient.album_id', '=', $req->album)
            ->get();

        $lesphotos = "";

        if ($listeDesPhotos->count() == 0) {
            $lesphotos = "<p>Aucune photo disponible</p>";
        } else {
            foreach ($listeDesPhotos as $photo)
            {
                $immgLoc = $photo->fichier;
                $imgName = $photo->nom;
                $lesphotos .= "<div><img title='" . $imgName . "' alt='" . $imgName . "' src='/storage" . substr($immgLoc, 6) . "' class='img-thumbnail'>"; 
                $lesphotos .= "<br><p><strong>Nom : </strong>" . $imgName . "</p></div>";
            }
        }
        echo $lesphotos;
       
    }

    function listeAlbumSelect(Request $req) {

        $id = DB::table('users')->where('email', Auth::user()->email)->value('id');
        $listeDesAlbums = DB::table('album')->where('album.realisateur_id', '=',$id)->get();
        $lesalbums = "";

        if ($listeDesAlbums->count() == 0) {
            $lesalbums = "<option>Aucun album disponible. Vous devez en créer un nouveau.</option>";
        } else {
            $lesalbums = "<option value='-1'>Choisir un album</option>";
            foreach ($listeDesAlbums as $album)
            {
                $albumName = $album->nom;
                $albumId = $album->id;
                $lesalbums .= "<option value='" . $albumId . "'>" . $albumName . "</option>";
            }
        }

        echo $lesalbums;

    }

}
