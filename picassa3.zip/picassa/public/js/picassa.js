function ajouterMaPhoto() {
    var test = document.getElementById("formAjouterPhoto");
    if (test) {
        $(document).on('submit', '#formAjouterPhoto', function(e) {
            form = $('#formAjouterPhoto')[0];
            formdata1 = new FormData(form);
            e.preventDefault();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: $('#formAjouterPhoto').attr('action'),
                data: formdata1,
                processData: false,
                contentType: false,
                type: 'POST'
            })
            .done(function(data) {
                swal("Photo Ajouté avec succès !");
            })
            .fail(function(data) {
                swal("La photo n'a pu être ajouté !");
            });
        });
    }
}

function CreerUnAlbum() {
    var test = document.getElementById("formAjouterAlbum");
    if (test) {
        $(document).on('submit', '#formAjouterAlbum', function(e) {

            form = $('#formAjouterAlbum')[0];
            formdata1 = new FormData(form);
            e.preventDefault();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: $('#formAjouterAlbum').attr('action'),
                data: formdata1,
                processData: false,
                contentType: false,
                type: 'POST'
            })
            .done(function(data) {
                swal("Album Ajouté avec succès !");
            })
            .fail(function(data) {
                swal("L'Album' n'a pu être ajouté !");
            });
        });
    }
}

function afficherMesphotos() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        url: '/mes-photos/',
        processData: false,
        contentType: false,
        type: 'POST'
    })
    .done(function(data) {
        document.getElementById('liste-des-photos').innerHTML = data;
    })
    .fail(function(data) {
    });
}

function afficherMesalbums() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        url: '/mes-albums/',
        processData: false,
        contentType: false,
        type: 'POST'
    })
    .done(function(data) {
        document.getElementById('liste-des-albums').innerHTML = data;
    })
    .fail(function(data) {
    });
}

function listeDesphotos() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        url: '/liste-des-photos/',
        processData: false,
        contentType: false,
        type: 'POST'
    })
    .done(function(data) {
        document.getElementById('liste-des-photos').innerHTML = data;
    })
    .fail(function(data) {
    });
}

function listeDesPhotosParAlbum() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        url: window.location.pathname,
        processData: false,
        contentType: false,
        type: 'POST'
    })
    .done(function(data) {
        document.getElementById('liste-des-photos').innerHTML = data;
    })
    .fail(function(data) {
    });
}

function listeDesalbums() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        url: '/liste-des-albums/',
        processData: false,
        contentType: false,
        type: 'POST'
    })
    .done(function(data) {
        document.getElementById('liste-des-albums').innerHTML = data;
    })
    .fail(function(data) {
    });
}

function listeAlbumSelect() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        url: '/listeAlbumSelect/',
        processData: false,
        contentType: false,
        type: 'POST'
    })
    .done(function(data) {
        document.getElementById('listeAlbum').innerHTML = data;
    })
    .fail(function(data) {
    });
}

function lancement() {
    ajouterMaPhoto();
    CreerUnAlbum();
}

window.onload = lancement;