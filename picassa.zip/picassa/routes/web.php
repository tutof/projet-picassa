<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/











Route::get('/', function () {
    return view('welcome');
});

Route::get('/liste-des-albums/', function () {
    return view('./liste-des-albums');
});

Route::get('/liste-des-photos/', function () {
    return view('./liste-des-photos');
});

Route::get('/ajouter-une-photo/', function () {
    return view('./ajouter-une-photo');
});

Route::get('/mon-compte/', function () {
    return view('./mon-compte');
});

Route::get('/les-personnes-que-je-suis/', function () {
    return view('./les-personnes-que-je-suis');
});

Route::get('/mes-photos/', function () {
    return view('./mes-photos');
});

Route::get('/mes-albums/', function () {
    return view('./mes-albums');
});

Route::get('/creer-un-album/', function () {
    return view('./creer-un-album');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
