<?php echo e($slot); ?>

<?php /**PATH C:\Users\1833\Documents\LP-Creaweb\picassa\picassa\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>