@extends('layouts.app')

@section('content')
<div class="content text-center">
    <br>
    <br>
    <br>
    <h1>{{ Auth::user()->name }}</h1>
    <br>
    <h3>{{ Auth::user()->email }}</h3>
</div>
@endsection