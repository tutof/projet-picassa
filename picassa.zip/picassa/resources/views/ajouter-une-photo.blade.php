@extends('layouts.app')

@section('content')
<div class="content text-center">
    <br>
    <br>
    <br>
    <h1>Ajouter une photo</h1>
    <br>
    <h3>{{ Auth::user()->name }}</h3>
    <br>
    <br>
    <br>
    <form class="mx-auto text-center" style="width: 500px;" action="upload" method="POST" enctype="multipart/form-data">
        <input required class="w-100" style="width: 300px;" type="file" name="image" class="form-control">
        @csrf
        <br>
        <br>
        <br>
        <button type="submit" class="btn btn-success">Ajouter l'image</button>
    </form>
</div>
@endsection