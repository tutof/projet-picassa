@extends('layouts.app')

@section('content')
<div class="content">
    <div class="text-center">
        Picassa
    </div>

    <div class="text-center">
        <a href="https://laravel.com/docs">Liste des albums</a>
        <a href="https://laracasts.com">Liste des photos</a>
    </div>
</div>
@endsection