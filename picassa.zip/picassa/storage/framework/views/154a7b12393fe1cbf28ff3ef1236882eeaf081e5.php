<?php $__env->startSection('content'); ?>
<div class="content text-center">
    <br>
    <br>
    <br>
    <h1>Ajouter une photo</h1>
    <br>
    <h3><?php echo e(Auth::user()->name); ?></h3>
    <br>
    <br>
    <br>
    <form class="mx-auto text-center" style="width: 500px;" action="upload" method="POST" enctype="multipart/form-data">
        <input required class="w-100" style="width: 300px;" type="file" name="image" class="form-control">
        <?php echo csrf_field(); ?>
        <br>
        <br>
        <br>
        <button type="submit" class="btn btn-success">Ajouter l'image</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\1833\Documents\LP-Creaweb\picassa\picassa\resources\views///ajouter-une-photo.blade.php ENDPATH**/ ?>