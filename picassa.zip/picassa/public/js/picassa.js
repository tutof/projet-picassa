function envoyerMaPhoto() {
    $(document).on('submit', '#formAjouterPhoto', function(e) {
        form = $('#formAjouterPhoto')[0];
        formdata1 = new FormData(form);
        /*
        formdata1.append('_token', $('#token').val());
        var fullPath = document.getElementById('photo-image').value;
        if (fullPath) {
            var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
            var filename = fullPath.substring(startIndex);
            if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
                filename = filename.substring(1);
            }
        }
        formdata1.append('image', document.getElementById('photo-image').files[0], filename);
        formdata1.append('nom', jQuery('#photo-nom').val());
        */

        e.preventDefault();
        $.ajax({
            url: $('#formAjouterPhoto').attr('action'),
            data: formdata1,
            processData: false,
            contentType: false,
            type: 'POST'
        })
        .done(function(data) {
            swal("Photo Ajouté avec succès !");
        })
        .fail(function(data) {
            swal("La photo n'a pu être ajouté !");
        });
   });
}

function lancement() {
    envoyerMaPhoto();
}

window.onload = lancement;