<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class Users extends Controller
{
    function ajouterPhotos(Request $req) {

        $id = DB::table('users')->where('email', Auth::user()->email)->value('id');
        DB::table('photo')->insertGetId(['nom' => $req->post('nom'), 'fichier' => $req->file('image')->store('public'), 'post_date' => date('Y-m-d H:i:s'), 'style' => 'no', 'utilisateur_id' => $id]);

    }
    function mesPhotos(Request $req) {
        $lesphotos = "<img alt='photo1' src='/storage/ok.png'>";
        echo $lesphotos;
    }
}
