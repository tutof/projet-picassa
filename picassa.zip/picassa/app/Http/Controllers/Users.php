<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Users extends Controller
{
    function index(Request $req) {
        //print_r($req->file());
        $req->file('image')->store('upload');
        echo "<script>
                alert('photo ajoute avec success');
                location.href='/ajouter-une-photo/';
             </script>";
    }
}
