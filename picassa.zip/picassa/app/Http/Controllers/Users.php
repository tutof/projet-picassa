<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class Users extends Controller
{
    function index(Request $req) {

        $id = DB::table('users')->where('email', Auth::user()->email)->value('id');
        DB::table('photo')->insertGetId(['nom' => $req->post('nom'), 'fichier' => $req->file('image')->store('upload'), 'post_date' => date('Y-m-d H:i:s'), 'style' => 'no', 'utilisateur_id' => $id]);
        
        return "<script>
               swal('photo ajoute avec success');
               location.href='/ajouter-une-photo/';
              </script>";
    }
}
