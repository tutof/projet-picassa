<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="text-center">
        Picassa
    </div>

    <div class="text-center">
        <a href="https://laravel.com/docs">Liste des albums</a>
        <a href="https://laracasts.com">Liste des photos</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\1833\Documents\LP-Creaweb\picassa\picassa\resources\views///liste-des-albums.blade.php ENDPATH**/ ?>