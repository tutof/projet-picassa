function envoyerMaPhoto() {
    $(document).on('submit', '#formAjouterPhoto', function(e) {
        form = $('#formAjouterPhoto')[0];
        formdata1 = new FormData(form);
        e.preventDefault();
        $.ajax({
            url: $('#formAjouterPhoto').attr('action'),
            data: formdata1,
            processData: false,
            contentType: false,
            type: 'POST'
        })
        .done(function(data) {
            swal("Photo Ajouté avec succès !");
        })
        .fail(function(data) {
            swal("La photo n'a pu être ajouté !");
        });
   });
}

function afficherMesphotos() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        url: '/mes-photos/',
        processData: false,
        contentType: false,
        type: 'POST'
    })
    .done(function(data) {
        console.log(data);
        document.getElementById('liste-des-photos').innerHTML = data;
    })
    .fail(function(data) {
    });
}

function lancement() {
    envoyerMaPhoto();
}

window.onload = lancement;